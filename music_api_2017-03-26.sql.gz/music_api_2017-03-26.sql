# ************************************************************
# Sequel Pro SQL dump
# Version 4529
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: localhost (MySQL 5.6.35)
# Database: music_api
# Generation Time: 2017-03-26 15:39:29 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table albums
# ------------------------------------------------------------

DROP TABLE IF EXISTS `albums`;

CREATE TABLE `albums` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `_hash` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `release_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `albums__hash_unique` (`_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `albums` WRITE;
/*!40000 ALTER TABLE `albums` DISABLE KEYS */;

INSERT INTO `albums` (`id`, `_hash`, `name`, `release_date`, `created_at`, `updated_at`, `deleted_at`)
VALUES
	(1,'3773be46f7b6e1ed91118013693ffc89','Jomsviking','2016-03-25','2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(2,'ef41c03d9ac9ba37b721f4e74aa439a0','Deceiver of the Gods','2013-06-25','2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(3,'a7df1b58ca3754eaf5224581af79340f','Caravan Palace','2008-10-20','2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(4,'89ab5d0e435900bede5625686a67767a','Thriller','1982-11-30','2017-03-26 15:37:28','2017-03-26 15:37:28',NULL);

/*!40000 ALTER TABLE `albums` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table albums_artists
# ------------------------------------------------------------

DROP TABLE IF EXISTS `albums_artists`;

CREATE TABLE `albums_artists` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `artists_id` int(10) unsigned NOT NULL,
  `albums_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `albums_artists_artists_id_foreign` (`artists_id`),
  KEY `albums_artists_albums_id_foreign` (`albums_id`),
  CONSTRAINT `albums_artists_albums_id_foreign` FOREIGN KEY (`albums_id`) REFERENCES `albums` (`id`) ON DELETE CASCADE,
  CONSTRAINT `albums_artists_artists_id_foreign` FOREIGN KEY (`artists_id`) REFERENCES `artists` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `albums_artists` WRITE;
/*!40000 ALTER TABLE `albums_artists` DISABLE KEYS */;

INSERT INTO `albums_artists` (`id`, `artists_id`, `albums_id`)
VALUES
	(1,1,1),
	(2,1,2),
	(3,2,3),
	(4,3,4);

/*!40000 ALTER TABLE `albums_artists` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table albums_genres
# ------------------------------------------------------------

DROP TABLE IF EXISTS `albums_genres`;

CREATE TABLE `albums_genres` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `albums_id` int(10) unsigned NOT NULL,
  `genres_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `albums_genres_albums_id_foreign` (`albums_id`),
  KEY `albums_genres_genres_id_foreign` (`genres_id`),
  CONSTRAINT `albums_genres_albums_id_foreign` FOREIGN KEY (`albums_id`) REFERENCES `albums` (`id`) ON DELETE CASCADE,
  CONSTRAINT `albums_genres_genres_id_foreign` FOREIGN KEY (`genres_id`) REFERENCES `genres` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `albums_genres` WRITE;
/*!40000 ALTER TABLE `albums_genres` DISABLE KEYS */;

INSERT INTO `albums_genres` (`id`, `albums_id`, `genres_id`)
VALUES
	(1,1,1),
	(2,2,1),
	(3,3,2),
	(4,4,3);

/*!40000 ALTER TABLE `albums_genres` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table albums_images
# ------------------------------------------------------------

DROP TABLE IF EXISTS `albums_images`;

CREATE TABLE `albums_images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `albums_id` int(10) unsigned NOT NULL,
  `images_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `albums_images_albums_id_foreign` (`albums_id`),
  KEY `albums_images_images_id_foreign` (`images_id`),
  CONSTRAINT `albums_images_albums_id_foreign` FOREIGN KEY (`albums_id`) REFERENCES `albums` (`id`) ON DELETE CASCADE,
  CONSTRAINT `albums_images_images_id_foreign` FOREIGN KEY (`images_id`) REFERENCES `images` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `albums_images` WRITE;
/*!40000 ALTER TABLE `albums_images` DISABLE KEYS */;

INSERT INTO `albums_images` (`id`, `albums_id`, `images_id`)
VALUES
	(1,1,2),
	(2,2,3),
	(3,3,5),
	(4,4,7);

/*!40000 ALTER TABLE `albums_images` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table artists
# ------------------------------------------------------------

DROP TABLE IF EXISTS `artists`;

CREATE TABLE `artists` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `_hash` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `artists__hash_unique` (`_hash`),
  UNIQUE KEY `artists_name_unique` (`name`),
  KEY `artists_image_id_foreign` (`image_id`),
  CONSTRAINT `artists_image_id_foreign` FOREIGN KEY (`image_id`) REFERENCES `images` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `artists` WRITE;
/*!40000 ALTER TABLE `artists` DISABLE KEYS */;

INSERT INTO `artists` (`id`, `_hash`, `name`, `image_id`, `created_at`, `updated_at`, `deleted_at`)
VALUES
	(1,'344710edaf968fd51946c21101b877a0','Amon Amarth',1,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(2,'c372a17e2a6485fab6dd9a8403590398','Caravan Palace',4,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(3,'5a123f8751c52ba8e26d5d51fa21c913','Michael Jackson',6,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL);

/*!40000 ALTER TABLE `artists` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table artists_tracks
# ------------------------------------------------------------

DROP TABLE IF EXISTS `artists_tracks`;

CREATE TABLE `artists_tracks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `artists_id` int(10) unsigned NOT NULL,
  `tracks_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `artists_tracks_artists_id_foreign` (`artists_id`),
  KEY `artists_tracks_tracks_id_foreign` (`tracks_id`),
  CONSTRAINT `artists_tracks_artists_id_foreign` FOREIGN KEY (`artists_id`) REFERENCES `artists` (`id`) ON DELETE CASCADE,
  CONSTRAINT `artists_tracks_tracks_id_foreign` FOREIGN KEY (`tracks_id`) REFERENCES `tracks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `artists_tracks` WRITE;
/*!40000 ALTER TABLE `artists_tracks` DISABLE KEYS */;

INSERT INTO `artists_tracks` (`id`, `artists_id`, `tracks_id`)
VALUES
	(1,1,1),
	(2,1,2),
	(3,1,3),
	(4,1,4),
	(5,1,5),
	(6,1,6),
	(7,1,7),
	(8,1,8),
	(9,1,9),
	(10,1,10),
	(11,1,11),
	(12,1,12),
	(13,1,13),
	(14,1,14),
	(15,1,15),
	(16,1,16),
	(17,1,17),
	(18,1,18),
	(19,1,19),
	(20,1,20),
	(21,1,21),
	(22,2,1),
	(23,2,2),
	(24,2,3),
	(25,2,4),
	(26,2,5),
	(27,2,6),
	(28,2,7),
	(29,2,8),
	(30,2,9),
	(31,2,10),
	(32,2,11),
	(33,2,12),
	(34,2,13),
	(35,2,14),
	(36,2,15),
	(37,2,16),
	(38,2,17),
	(39,2,18),
	(40,2,19),
	(41,2,20),
	(42,2,21),
	(43,2,22),
	(44,2,23),
	(45,2,24),
	(46,2,25),
	(47,2,26),
	(48,2,27),
	(49,2,28),
	(50,2,29),
	(51,2,30),
	(52,2,31),
	(53,2,32),
	(54,2,33),
	(55,2,34),
	(56,2,35),
	(57,2,36),
	(58,3,1),
	(59,3,2),
	(60,3,3),
	(61,3,4),
	(62,3,5),
	(63,3,6),
	(64,3,7),
	(65,3,8),
	(66,3,9),
	(67,3,10),
	(68,3,11),
	(69,3,12),
	(70,3,13),
	(71,3,14),
	(72,3,15),
	(73,3,16),
	(74,3,17),
	(75,3,18),
	(76,3,19),
	(77,3,20),
	(78,3,21),
	(79,3,22),
	(80,3,23),
	(81,3,24),
	(82,3,25),
	(83,3,26),
	(84,3,27),
	(85,3,28),
	(86,3,29),
	(87,3,30),
	(88,3,31),
	(89,3,32),
	(90,3,33),
	(91,3,34),
	(92,3,35),
	(93,3,36),
	(94,3,37),
	(95,3,38),
	(96,3,39),
	(97,3,40),
	(98,3,41),
	(99,3,42),
	(100,3,43),
	(101,3,44),
	(102,3,45);

/*!40000 ALTER TABLE `artists_tracks` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table genres
# ------------------------------------------------------------

DROP TABLE IF EXISTS `genres`;

CREATE TABLE `genres` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `_hash` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `genres__hash_unique` (`_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `genres` WRITE;
/*!40000 ALTER TABLE `genres` DISABLE KEYS */;

INSERT INTO `genres` (`id`, `_hash`, `title`, `created_at`, `updated_at`, `deleted_at`)
VALUES
	(1,'92fcc1dd091e9f00e147ecb1127a52c8','Melodic Death Metal','2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(2,'7f0a2199e4f81de3f733b9d824612eb2','Electro Swing','2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(3,'5621c5578a57096260b7d8aa11da421c','Pop','2017-03-26 15:37:28','2017-03-26 15:37:28',NULL);

/*!40000 ALTER TABLE `genres` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table images
# ------------------------------------------------------------

DROP TABLE IF EXISTS `images`;

CREATE TABLE `images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `width` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `images` WRITE;
/*!40000 ALTER TABLE `images` DISABLE KEYS */;

INSERT INTO `images` (`id`, `name`, `file`, `width`, `height`, `created_at`, `updated_at`, `deleted_at`)
VALUES
	(1,'Amon Amarth','http://www.metal-archives.com/images/1/5/0/150_photo.jpg',151,473,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(2,'Jomsviking','https://upload.wikimedia.org/wikipedia/en/thumb/7/7a/AmonAmarthJomsviking.jpg/220px-AmonAmarthJomsviking.jpg',494,199,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(3,'Deceiver of the Gods','https://upload.wikimedia.org/wikipedia/en/thumb/2/2f/DeceiveroftheGodsAmonAmarth.jpg/220px-DeceiveroftheGodsAmonAmarth.jpg',351,313,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(4,'Caravan Palace','http://floodmagazine.com/wp-content/uploads/2015/10/Caravan_Palace-2015-Antoine_Delaporte.jpg',230,159,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(5,'Caravan Palace','https://upload.wikimedia.org/wikipedia/en/thumb/1/13/Caravan_Palace.png/220px-Caravan_Palace.png',126,280,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(6,'Michael Jackson','http://www.bransonshowtickets.com/media/3235117784_o.jpg',274,163,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(7,'Thriller','https://upload.wikimedia.org/wikipedia/en/thumb/5/55/Michael_Jackson_-_Thriller.png/220px-Michael_Jackson_-_Thriller.png',435,152,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL);

/*!40000 ALTER TABLE `images` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table migrations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;

INSERT INTO `migrations` (`id`, `migration`, `batch`)
VALUES
	(1,'2014_10_12_000000_create_users_table',1),
	(2,'2017_03_22_230424_create_images_table',1),
	(3,'2017_03_22_230535_create_artists_table',1),
	(4,'2017_03_22_231008_create_albums_table',1),
	(5,'2017_03_22_231822_create_genres_table',1),
	(6,'2017_03_22_232123_create_albums_images_table',1),
	(7,'2017_03_22_232158_create_tracks_table',1),
	(8,'2017_03_22_232343_create_albums_artists_table',1),
	(9,'2017_03_22_232508_create_albums_genres_table',1),
	(10,'2017_03_24_230537_create_artists_tracks_table',1),
	(11,'2017_03_25_141400_create_users_tokens_table',1);

/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table tracks
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tracks`;

CREATE TABLE `tracks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `_hash` varchar(255) NOT NULL,
  `album_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `length` int(11) NOT NULL,
  `disc_number` int(11) NOT NULL,
  `track_order` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tracks__hash_unique` (`_hash`),
  KEY `tracks_album_id_foreign` (`album_id`),
  CONSTRAINT `tracks_album_id_foreign` FOREIGN KEY (`album_id`) REFERENCES `albums` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `tracks` WRITE;
/*!40000 ALTER TABLE `tracks` DISABLE KEYS */;

INSERT INTO `tracks` (`id`, `_hash`, `album_id`, `title`, `length`, `disc_number`, `track_order`, `created_at`, `updated_at`, `deleted_at`)
VALUES
	(1,'0a844377e4fa577e2c2c4fe4dde135d3',1,'First Kill',261,1,1,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(2,'b7129543812b9e1a46fc3a0f5d29f216',1,'Wanderer',282,1,2,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(3,'fcdc951492feaf5a21d15444c1853c45',1,'On a Sea of Blood',244,1,3,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(4,'d1a2ef4687207a90f0b333a75c415e4c',1,'One Against All',217,1,4,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(5,'175e3421b1079aebcb54bae4b8774e7e',1,'Raise Your Horns',263,1,5,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(6,'dc42ae08d8d197d3002a5a1ad2e80c05',1,'The Way of Vikings',311,1,6,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(7,'8ab5df79adf62e984733aad966d5ebc0',1,'At Dawn’s First Light',230,1,7,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(8,'b816e1c2b18090967380721b3bec5234',1,'One Thousand Burning Arrows',349,1,8,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(9,'7ff3320aaec897798336245a732394e8',1,'Vengeance Is My Name',281,1,9,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(10,'9d3e73eb7ab40092293afc2bebb5ce73',1,'A Dream That Cannot Be',262,1,10,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(11,'30b35e8994df5d833779bceb91a5d1f2',1,'Back on Northern Shores',428,1,11,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(12,'56af7b01b2a4b90acbcf87a5f8e26d82',2,'Deceiver of the Gods',259,1,1,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(13,'4d47a460f151fb0cd7aa3f15d348ffd8',2,'As Loke Falls',278,1,2,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(14,'52ed4c96ef9396edd68d1d1f9bfe236c',2,'Father of the Wolf',259,1,3,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(15,'ee6547c6352f8d778a03288463ffe966',2,'Shape Shifter',242,1,4,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(16,'0e14469333eb27657ca6b76aa91e2d18',2,'Under Siege',377,1,5,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(17,'95bdf821f30b8c0a26495403f482e534',2,'Blood Eagle',195,1,6,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(18,'2160c48ac599dc95bbf3e97f791e27d1',2,'We Shall Destroy',265,1,7,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(19,'3ffe043b0bcf647da02b0b6db6b72ac3',2,'Hel',249,1,8,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(20,'73c37834fa5040f63918c7e541b401fc',2,'Coming of the Tide',256,1,9,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(21,'666cc3ee7915bb645221f8add70d5e2c',2,'Warriors of the North',492,1,10,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(22,'c70e14b0f47a875f953260a6db4cc075',3,'Dragons',245,1,1,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(23,'07ad956ce097cc9781448336fc85e416',3,'Star Scat',230,1,2,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(24,'da3888371a8bc238074a409bb761410a',3,'Ended With the Night',300,1,3,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(25,'1ae6050265a4776bd832d4e8ea9697c4',3,'Jolie Coquine',226,1,4,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(26,'64a5cb568a25d42bef19528a2f440455',3,'Oooh',109,1,5,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(27,'5ba6d954fa42d6c32948b523b7bd5d25',3,'Suzy',307,1,6,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(28,'ce6c6f4cbe3f46bb8c241311f9b9bd47',3,'Je MAmuse',214,1,7,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(29,'cfc26f4213f9ee888c3ced5f9d71263b',3,'Violente Valse',215,1,8,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(30,'c875d3ff471f2a1a1c91f3471c55b839',3,'Brotherswing',222,1,9,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(31,'b9a7adfede41cebd53ac6dc6fb4cce12',3,'LEnvol',226,1,10,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(32,'7c5c15e9e8bd4eabf04f15f84bf0839c',3,'Sofa',51,1,11,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(33,'6e138163ce72cd5c56992c0a52bd2169',3,'Bambous',194,1,12,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(34,'3ad28b1e052ee66bb56ae8895983e5c7',3,'Lazy Place',237,1,13,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(35,'7a33affa0e70841e9fdc5eb89c31423d',3,'We Can Dance',263,1,14,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(36,'1fa9e06f2261aacd9195eb41ac27ecaa',3,'La Caravane',305,1,15,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(37,'d9be33376070059782691f11fde1ad01',4,'Wanna Be Startin Somethin',364,1,1,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(38,'3245a8dbb2b96e8f5095be7a9c67d372',4,'Baby Be Mine',261,1,2,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(39,'6a206a4867124bf6b3b201f8d696ea7f',4,'The Girl Is Mine',129,1,3,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(40,'34d9157df21403202708cb9a252b6433',4,'Thriller',358,1,4,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(41,'6c3c8a72df24ec83828cfdb111c1acb0',4,'Beat It',258,2,5,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(42,'be4a4db7b5a29f4c6211e024ee8fd0e6',4,'Billie Jean',294,2,6,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(43,'8c91abe45a6d03ce43be1966a13b295b',4,'Human Nature',247,2,7,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(44,'ac0f4c805cf6738ab0c797c8e9d318d9',4,'P.Y.T. (Pretty Young Thing)',238,2,8,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL),
	(45,'8e7b2396114a054dc5f62a80f21fa609',4,'The Lady in My Life',299,2,9,'2017-03-26 15:37:28','2017-03-26 15:37:28',NULL);

/*!40000 ALTER TABLE `tracks` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`, `deleted_at`)
VALUES
	(1,'Music API','api@musicapi.com','$2y$10$70JtcSQCyxgZlWQevHkPPOV8mEX/jC/66Ci/AKkYNvO8rgPPhTkhG',NULL,'2017-03-26 15:38:46','2017-03-26 15:38:46',NULL);

/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table users_tokens
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users_tokens`;

CREATE TABLE `users_tokens` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_tokens_token_unique` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `users_tokens` WRITE;
/*!40000 ALTER TABLE `users_tokens` DISABLE KEYS */;

INSERT INTO `users_tokens` (`id`, `user_id`, `token`, `created_at`, `updated_at`)
VALUES
	(1,1,'81d26c05-406e-49ef-8fc0-e92f0a640540','2017-03-26 15:38:46','2017-03-26 15:38:46');

/*!40000 ALTER TABLE `users_tokens` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
